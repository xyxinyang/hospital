/*
 Navicat Premium Data Transfer

 Source Server         : wamp
 Source Server Type    : MySQL
 Source Server Version : 50711
 Source Host           : localhost:3306
 Source Schema         : s79

 Target Server Type    : MySQL
 Target Server Version : 50711
 File Encoding         : 65001

 Date: 13/10/2018 21:31:05
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `age` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `name`(`name`) USING BTREE,
  UNIQUE INDEX `idxlq_name`(`name`) USING BTREE,
  INDEX `idx_name`(`name`) USING BTREE,
  INDEX `idxl_name`(`name`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 52 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES (6, '安娜', 80);
INSERT INTO `user` VALUES (7, '天使', 30);
INSERT INTO `user` VALUES (8, '查莉娅', 36);
INSERT INTO `user` VALUES (9, '黑百合', 32);
INSERT INTO `user` VALUES (10, '猎空', 23);
INSERT INTO `user` VALUES (11, '狂鼠', 40);
INSERT INTO `user` VALUES (12, '托比昂', 50);
INSERT INTO `user` VALUES (13, 'D.Va', 20);
INSERT INTO `user` VALUES (14, '源氏', 35);
INSERT INTO `user` VALUES (15, '死神', 40);
INSERT INTO `user` VALUES (17, '堡垒', 99);
INSERT INTO `user` VALUES (18, '老王', 40);
INSERT INTO `user` VALUES (19, '小美', 23);
INSERT INTO `user` VALUES (20, '莱因哈特', 80);

DROP TABLE IF EXISTS `yuyue`;
CREATE TABLE `yuyue`(
	`id` int UNSIGNED NOT NULL AUTO_INCREMENT,
	`name` char(20) NOT NULL,
	`id_card` char(18) NOT NULL,
	PRIMARY KEY (`id`)
	);

INSERT INTO `yuyue` VALUES (1,'zc','411503200006060419');

DROP TABLE IF EXISTS `charge`;
CREATE TABLE `charge`(
  id int UNSIGNED not null AUTO_INCREMENT,
  level int not null,
  keshi char(10) not null,
  cost int not null,
  PRIMARY KEY(id)
);

INSERT INTO `charge` VALUES (1,1,'儿科',10);
INSERT INTO `charge` VALUES (2,2,'儿科',20);
INSERT INTO `charge` VALUES (3,3,'儿科',30);
INSERT INTO `charge` VALUES (4,1,'外科',40);
INSERT INTO `charge` VALUES (5,2,'外科',50);
INSERT INTO `charge` VALUES (6,3,'外科',60);
INSERT INTO `charge` VALUES (7,1,'内科',70);
INSERT INTO `charge` VALUES (8,2,'内科',80);
INSERT INTO `charge` VALUES (9,3,'内科',90);

DROP TABLE IF EXISTS `guahao`;
CREATE TABLE `guahao`(
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
	`name` char(20) NOT NULL,
	`id_card` char(18) NOT NULL,
  `keshi` char(10) NOT NULL,
  `level` int not null,
  `state` int NOT NULL,  -- 1 代表待挂号  2 代表已挂号在检查中  3 代表已检查待收费
  `drug` varchar(20) NOT NULL DEFAULT '',
  `price` int NOT null DEFAULT 0,
  `date` date not null,
	PRIMARY KEY (`id`)
);

INSERT INTO `guahao` VALUES (1,'zhangsan',12345678,'儿科',1,1,'',0,curdate());
INSERT INTO `guahao` VALUES (2,'lisi',87654321,'儿科',2,2,'',0,curdate());
INSERT INTO `guahao` VALUES (3,'wangwu',123456789,'儿科',3,1,'',0,curdate());
INSERT INTO `guahao` VALUES (4,'wangerma',123456,'儿科',2,3,'ganmaoyao',20,curdate());

DROP TABLE IF EXISTS `profit`;
CREATE TABLE `profit`(
  `id` int UNSIGNED not null AUTO_INCREMENT,
  `keshi` char(10) not null,
  `drug` varchar(20) not null,
  `all_price` int not null,
  `date` date not null,
  PRIMARY KEY(`id`)
);

INSERT INTO `profit` VALUES (1,'儿科','ganmaoyao',1500,curdate());
INSERT INTO `profit` VALUES (2,'儿科','fashaoyao',2500,'2021-5-11');
INSERT INTO `profit` VALUES (3,'儿科','xiaoyanyao',3500,'2021-4-11');
INSERT INTO `profit` VALUES (4,'外科','xiaoyanyao',4500,curdate());

CREATE TRIGGER to_profit
BEFORE DELETE on `guahao`
FOR EACH ROW
INSERT INTO `profit`(`keshi`,`drug`,`all_price`,`date`) VALUES (old.keshi,old.drug,old.price,old.date);

DROP TABLE IF EXISTS `drug_store`;
CREATE TABLE `drug_store`(
  `id` int UNSIGNED not null AUTO_INCREMENT,
  `drug` varchar(20) not null,
  `left` int not null DEFAULT 0,
  PRIMARY KEY(`id`)
);

INSERT INTO `drug_store` VALUES (1,'ganmaoyao',100);

-- DROP VIEW IF EXISTS `drug_usage`;
-- CREATE VIEW `drug_usage`(`d_keshi`,`d_drug`,`d_date`) as select `keshi`,`drug`,`date` from `profit` where `drug`='ganmaoyao';

-- set @drug_name='';

-- create function get_name()
-- returns char(20) 
-- return @drug_name;

-- DELIMITER //
-- CREATE PROCEDURE show_drug_usage(in name char(20))
-- BEGIN
-- DROP VIEW IF EXISTS `drug_usage`;
-- CREATE VIEW `drug_usage`(`d_keshi`,`d_drug`,`d_date`) as select `keshi`,`drug`,`date` from `profit` where `drug`= get_name();
-- select `keshi`,`drug`,`date` from `profit` where `drug`= name;
-- END //
-- DELIMITER ;
DROP VIEW IF EXISTS `erke_profit`;
CREATE VIEW `erke_profit`(`keshi`,`all_price`,`date`) as select `keshi`,`all_price`,`date` from `profit` where `keshi` = '儿科';

DROP PROCEDURE IF EXISTS show_drug_usage;
DELIMITER //
CREATE PROCEDURE show_drug_usage(in name char(20))
BEGIN
select `keshi`,`drug`,`date` from `profit` where `drug`= name;
END //
DELIMITER ;

SET FOREIGN_KEY_CHECKS = 1;
