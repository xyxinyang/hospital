var express = require('express');
var bodyParser = require('body-parser');
var path = require('path');//路径模块
var fs = require('fs');
var sql = require('./conf/visitor.js');
//var sql = require('./conf/mysql.js');
var guahao = require('./conf/guahao.js');
var jiancha = require('./conf/guahao.js');
var app = express();
var state = "未登录";


app.set('view engine','ejs');
app.set('views','./views/');
app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.urlencoded({ extended: false }));

app.get('/',function(req,res){
  res.render('index',{state:state});
});
// display charge
app.get('/charge',function(req,res){
  sql.query('select * from charge',function(err,result){
    if (err) {
      res.render('charge',{title:"导医收费",datas:[]});
    }else{
      res.render('charge',{title:"导医收费",datas:result});
    }
  })
});
// add user
app.get('/add',function(req,res){
  res.render('add');
});

app.post('/add',function(req,res){
  var name = req.body.name;
  var id_card = req.body.id_card;
  var keshi = req.body.keshi;
  var level = req.body.level;
  sql.query('insert into guahao(name,id_card,keshi,level,state,date) values("'+name+'","'+ id_card +'","'+ keshi +'","'+ level +'",1,curdate\(\))',function(err,result){
     if(err){
            res.send('挂号失败'+err);
        }else {
          res.render('index',{state:state});
        }
  });
});
// display guahao
app.get('/guahao',function(req,res){
  sql.query('select * from guahao where state=1',function(err,result){
    if (err) {
      res.render('guahao',{title:"已挂号",datas:[]});
    }else{
      res.render('guahao',{title:"已挂号",datas:result});
    }
  })
});
// let guahao to jiancha
app.get('/guahao/:id',function(req,res){
  var id = req.params.id;
  sql.query('update guahao set state=2 where id = '+id,function(err,result){
      sql.query('select * from guahao where state=1',function(err,result){
        if (err) {
          res.render('guahao',{title:"已挂号",datas:[]});
        }else{
          res.render('guahao',{title:"已挂号",datas:result});
        }
      })
  });
});
// display jiancha
app.get('/jiancha',function(req,res){
  sql.query('select * from guahao where state=2',function(err,result){
    if (err) {
      res.render('jiancha',{title:"正在检查",datas:[]});
    }else{
      res.render('jiancha',{title:"正在检查",datas:result});
    }
  })
});
//kaiyao
app.get('/kaiyao/:id',function(req,res){
  var id = req.params.id;
  sql.query('select * from guahao where id = ' + id,function(err,result){
          res.render('kaiyao',{datas:result});
  });
});

app.post('/kaiyao',function(req,res){
var id = req.body.id;
var drug = req.body.drug;
var price = req.body.price;
sql.query('update guahao set state=3, drug = "'+drug+'"  , price = "'+price+'" where id = '+id,function(err,result){
  sql.query('select * from guahao where state=2',function(err,result){
    if (err) {
      res.render('jiancha',{title:"正在检查",datas:[]});
    }else{
      res.render('jiancha',{title:"正在检查",datas:result});
    }
  })
})

});
// display daishoufei
app.get('/dai',function(req,res){
  sql.query('select * from guahao where state=3',function(err,result){
    if (err) {
      res.render('dai',{title:"待收费",datas:[]});
    }else{
      res.render('dai',{title:"待收费",datas:result});
    }
  })
});
// shoufei
app.get('/dai/:id',function(req,res){
  var id = req.params.id;
  sql.query('delete from guahao where id = '+id,function(err,result){
    sql.query('select * from guahao where state=3',function(err,result){
      if (err) {
        res.render('dai',{title:"待收费",datas:[]});
      }else{
        res.render('dai',{title:"待收费",datas:result});
      }
    })
 });
});
// display drug_useage
app.get('/search-drug',function(req,res){
  res.render('search-drug');
});
app.post('/drug-usage',function(req,res){
  var name = req.body.drug;
  var cmd = 'select * from profit where drug=\''+name+'\'';
  console.log(cmd);
  sql.query(cmd,function(err,result){
    if(err){
      res.render('drug-usage',{title:"药使用情况",datas:[]});
    }
    else{
      res.render('drug-usage',{title:name+"使用情况",datas:result});
    }
  })
});
// display keshi-profit

// display profit
app.get('/profit',function(req,res){
  res.render('profit');
});
app.get('/day-profit',function(req,res){
  sql.query('select * from profit where date=curdate()',function(err,result){
    if(err){
      res.render('detailed',{title:"日报表",datas:[]});
    }
    else{
      res.render('detailed',{title:"日报表",datas:result});
    }
  })
});
app.get('/month-profit',function(req,res){
  sql.query('select * from profit where MONTH(date)=MONTH(curdate()) and YEAR(date)=YEAR(curdate())',function(err,result){
    if(err){
      res.render('detailed',{title:"月报表",datas:[]});
    }
    else{
      res.render('detailed',{title:"月报表",datas:result});
    }
  })
});
app.get('/year-profit',function(req,res){
  sql.query('select * from profit where YEAR(date)=YEAR(curdate())',function(err,result){
    if(err){
      res.render('detailed',{title:"年报表",datas:[]});
    }
    else{
      res.render('detailed',{title:"年报表",datas:result});
    }
  })
});
// display user
app.get('/user',function(req,res){
        sql.query('select * from user',function(err,result){
          if (err) {
            res.render('user',{title:"用户列表",datas:[]});
          }else{
            res.render('user',{title:"用户列表",datas:result});
          }
        });
});
//denglu
app.get('/denglu',function(req,res){
  res.render('denglu');
});
app.post('/denglu',function(req,res){
  var name = req.body.name;
  var passwd = req.body.passwd;
  if(name=='guahao_p'&&passwd=='guahao') 
  {
    sql = guahao;
    state = 'guahao_p';
    res.render('index',{state:'guahao_p'});
  }
  else if(name=='jiancha_p'&&passwd=='jiancha')
  {
    sql = jiancha;
    state = 'jiancha_p';
    res.render('index',{state:'jiancha_p'});
  }
  else if(name=='shoufei_p'&&passwd=='shoufei')
  {
    sql = shoufei;
    state = 'shoufei_p';
    res.render('index',{state:'shoufei_p'});
  }
  else if(name=='root'&&passwd=='911911abc')
  {
    sql = require('./conf/mysql.js');
    state = 'root';
    res.render('index',{state:'root'});
  }
  else
  {
    res.render('index',{state:'未登录'});
  }
});
// tuichu
app.get('/exit',function(req,res){
  sql = require('./conf/visitor.js');
  state = "未登录";
  res.render('index',{state:"未登录"});
});

// edit user
app.get('/edit/:id',function(req,res){
    var id = req.params.id;
    sql.query('select * from user where id = ' + id,function(err,result){
            res.render('edit',{datas:result});
    });
});

app.post('/edit',function(req,res){
  var id = req.body.id;
  var name = req.body.name;
  var age = req.body.age;
  sql.query('update user set name = "'+name+'"  , age = "'+age+'" where id = '+id,function(err,result){
    if (err) {
      res.send('更新失败'+err);
    }else{
      res.redirect('/');
    }
  })

});


// del user
app.get('/del/:id',function(req,res){
  var id = req.params.id;
  sql.query('delete from user where id = '+id,function(err,result){
     if(err){
            res.send('删除失败'+err);
        }else {
            res.redirect('/');
        }
  });
});

app.listen(3000,function () {    //监听3000端口
  console.log('Server running at 3000 port');
});